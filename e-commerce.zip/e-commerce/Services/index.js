
'use strict';

module.exports = {
    queries: require('./queries')
};
