"use strict"

const Service = require("../Services").queries;
const { payload } = require("@hapi/hapi/lib/validation");
const Config = require("../Config");
const Model = require("../Models");

//Add Edit Cart
async function addEditCart(payloadData) {
    try {
        const { userId, products } = payloadData;
        payloadData.addedBy = userId
        let cart
        if (payloadData.cartId) {
            cart = await Service.findAndUpdate(Model.Cart, { _id: payloadData.cartId }, payloadData, { new: true, lean: true })
        } else {
            const data = await Service.findOne(Model.Cart, { addedBy: userId });
            if (data) {
                cart = await Service.findAndUpdate(Model.Cart, {
                    addedBy: userId
                }, { $push: { products: products } });
            } else {
                cart = await Service.saveData(Model.Cart, payloadData, { new: true, lean: true })
                const demo = cart.products;
                console.log("cart:" + demo);
            }
        }
        if (!cart)
            return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
        return cart
    } catch (err) {
        console.log(err);
        return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
    }
}

//Get cart
async function cartList() {
    try {
        const data = await Model.Cart.aggregate([
            {
                $lookup: {
                    from: "products",
                    localField: "products.productId",
                    foreignField: "_id",
                    as: "product_info",
                },
            },
            {
                $unwind: "$product_info"
            },
            {
                $lookup: {
                    from: "users",
                    localField: "addedBy",
                    foreignField: "_id",
                    as: "user_info",
                },
            },
            {
                $unwind: "$user_info"
            }
        ])
        return {
            cartData: data
        }

    } catch (err) {
        console.log(err);
        return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
    }
}


//Remove Items
async function removeItem(payloadData) {
    try {
        const { userId, productId } = payloadData;
        const data = await Service.findOne(Model.Cart, {
            addedBy: userId,
            isActive: true
        });
        if (!data)
            return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.NOT_EXIST);
        else {
            let obj = await Service.findAndUpdate(Model.Cart, {
                addedBy: userId
            }, { $pull: { products: { productId } } })
            return Config.APP_CONSTANTS.STATUS_MSG.SUCCESS.DELETED;
        }
    } catch (err) {
        console.log(err);
        return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
    }
}

//Delete Cart
async function deleteCart(paramsData) {
    try {
        let data = await Service.remove(Model.Cart, { _id: paramsData.cartId })
        return {
            cartData: data
        }
    } catch (err) {
        console.log(err);
        return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
    }
}




// //delete Items
// async function deleteItem(payloadData) {
//     try {
//         const { userId, productId } = payloadData;
//         const data = await Service.findOne(Model.Cart, {
//             addedBy: userId,
//             isActive: true
//         });
//         if (!data)
//             return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.NOT_EXIST);
//         else {
//             let obj = await Service.remove(Model.Cart, {
//                 productId: productId
//             })
//             return obj
//         }
//     } catch (err) {
//         console.log(err);
//         return Promise.reject(Config.APP_CONSTANTS.STATUS_MSG.ERROR.IMP_ERROR);
//     }
// }

module.exports = {
    addEditCart,
    cartList,
    deleteCart,
    // deleteItem,
    removeItem,
    // discount
}