module.exports = {
    APP_CONSTANTS: require('./appConstants'),
    dbConfig: require('./dbConfig'),
    awsS3Config: require('./awsS3Config'),
};