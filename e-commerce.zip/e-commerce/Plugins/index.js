
module.exports = [
    require('./swagger'),
    require('./auth-token')
];
