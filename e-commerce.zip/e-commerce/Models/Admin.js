let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let Admin = new Schema({
    fullName: {
        type: String,
    },
    email: {
        type: String,
    },
    password: {
        type: String
    },
    role: {
        type: String
    },
    mobile: {
        type: String
    },
    isDelete: {
        type: Boolean,
        default: false
    },
    addedBy: {
        type: Schema.ObjectId,
        ref: "Admin"
    },
    accessToken: {
        type: String
    }
}, {
    timestamps: true
});
module.exports = mongoose.model("admins", Admin)